

export interface IShow{
  show: () => Array<number>
}